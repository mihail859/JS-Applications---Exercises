import { html, render } from './node_modules/lit-html/lit-html.js';
import { mainTemplate } from './templates.js';

render(mainTemplate, document.querySelector('body'))






